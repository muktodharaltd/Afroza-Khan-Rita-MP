'use client'

import { useState } from 'react'
import Homes from './components/home/page'

export default function Home() {
  return (
    <div>
      <Homes />
    </div>
  )
}
