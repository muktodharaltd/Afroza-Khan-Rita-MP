// data/navItems.js

const navItems = [
  {
    name: 'প্রথম পাতা',
    href: '/',
  },
  {
    name: 'পরিচিতি',
    href: '/parichiti',
  },
  {
    name: 'যোগাযোগ',
    href: '/contact',
  },
  {
    name: 'নারী শক্তি',
    href: '/nari-shakti',
  },
]

export default navItems
